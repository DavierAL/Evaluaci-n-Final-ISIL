//
//  DetailsViewCell.swift
//  MovieFinal
//
//  Created by user213622 on 7/24/23.
//

import UIKit

class DetailsViewCell: UITableViewCell {
    
    func configure(with actor: Actor) {
            actorName.text = actor.name
            fakeName.text = actor.character
            if let url = URL(string: "https://image.tmdb.org/t/p/w500\(actor.imgPath ?? "")") {
                downloadImage(from: url) { [weak self] image, error in
                    if let error = error {
                        print("Error downloading image: \(error)")
                        return
                    }
                    DispatchQueue.main.async { self?.actorImg.image = image }
                }
            }
        }

        override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)
        }
        
        func downloadImage(from url: URL, completion: @escaping (UIImage?, Error?) -> Void) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error { completion(nil, error); return }
                
                    
            }.resume()
        }

    
    @IBOutlet var actorImg: UIImageView!
    @IBOutlet var actorName: UILabel!
    @IBOutlet var fakeName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
