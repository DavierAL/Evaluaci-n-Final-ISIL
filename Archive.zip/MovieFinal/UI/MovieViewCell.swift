//
//  MovieViewCell.swift
//  MovieFinal
//
//  Created by user213622 on 7/20/23.
//

import UIKit

class MovieViewCell: UITableViewCell {

  
    @IBOutlet var poster: UIImageView!
    @IBOutlet var name: UILabel!
    @IBOutlet var rate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
