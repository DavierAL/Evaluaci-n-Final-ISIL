//
//  DetailsVC.swift
//  MovieFinal
//
//  Created by user213622 on 7/20/23.
//

import UIKit

class DetailsVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Devuelve la cantidad de actores que tiene la película
        return actors.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Configura cada celda de la tabla con la información del actor correspondiente
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! DetailsViewCell
        let actor = actors[indexPath.row]
        cell.configure(with: actor)
        return cell
    }

  
    
    var movieId: Int?
    
    var actors: [Actor] = []
    var movie: Movie?

    @IBOutlet var castTable: UITableView!
    @IBOutlet var posterDetails: UIImageView!
    @IBOutlet var overviewText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadMovieDetail()
        
        castTable.dataSource = self
        castTable.delegate = self
        
        if let movie = movie {
               // Descargar la imagen
               if let url = URL(string: "https://image.tmdb.org/t/p/w500\(movie.poster_path ?? "")") {
                   downloadImage(from: url) { [weak self] image, error in
                       if let error = error {
                           print("Error image: \(error)")
                           return
                       }
                       
                       DispatchQueue.main.async {
                           self?.posterDetails.image = image
                       }
                   }
               }

               // Establecer la sinopsis
               overviewText.text = movie.overview

               // Establecer el título de la navigation bar
               navigationItem.title = movie.title

               // Descargar la lista de actores
            
               LoadActors(movieId: Int(movie.id)) { [weak self] (result: Result<[Actor], Error>) in
                   switch result {
                   case .success(let actors):
                       self?.actors = actors
                       DispatchQueue.main.async {
                           self?.castTable.reloadData()
                       }
                   case .failure(let error):
                       print("Error fetching actors: \(error)")
                   }
               }
           }
        
    }
    
    func downloadImage(from url: URL?, completion: @escaping (UIImage?, Error?) -> Void) {
        guard let url = url else {
            completion(nil, nil)
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, error)
                return
            }
            
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { completion(nil, nil); return }
            
            // Resizing the image if it's too large.
            
            
           
        }.resume()
    }
    
    func loadMovieDetail(){
        guard let movieId = movieId else {
            print("Error: invalid movie id")
            return
        }
        
        guard let url = URL(string: "https://api.themoviedb.org/3/movie/\(movieId)/credits?api_key=3cae426b920b29ed2fb1c0749f258325") else {
            print("Error: Invalid URL")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard error == nil else {
                print("Error: \(error!)")
                return
            }
            guard let data = data else {
                print("Error: Invalid data")
                return
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("Error: HTTP request failed")
                return
            }
            do {
                let movieDetail = try  JSONDecoder().decode(Movie.self, from: data)
                self.movieId = movieDetail.id
                
                DispatchQueue.main.async {
                    self.overviewText.text = movieDetail.overview
                    self.posterDetails.loadImage(from: "https://image.tmdb.org/t/p/w500\(movieDetail.poster_path ?? "null")")
                    
            
                    
              
                    
                }
            } catch (let error){
                print("Error:\(error)")
            }
        }
        task.resume()


   

}
}
